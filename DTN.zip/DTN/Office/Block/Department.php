<?php

namespace DTN\Office\Block;

use DTN\Office\Model\DepartmentFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;



class Department extends \Magento\Framework\View\Element\Template
{
    protected $_coreRegistry;
    protected $_departmentFactory;

    public function __construct(
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\View\Element\Template\Context $context,
        \DTN\Office\Model\DepartmentFactory $departmentFactory
    )
    {
        $this->_departmentFactory = $departmentFactory;
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context);

    }

    public function getDepartment()
    {
        return $this->_departmentFactory->create()->getCollection();
    }

    public function getEditRecord()
    {
        $id = $this->_coreRegistry->registry('editRecordId');       
        $department = $this->_departmentFactory->create();
        $result = $department->load($id)->getData();       
        return $result;
    }

    public function SaveEditRecord()
    {
        return '/office/department/update';
    }

    public function addNew()
    {   
        return '/office/department/insert';
    }

}
<?php

namespace DTN\Office\Block;

use DTN\Office\Model\EmployeeFactory;
use DTN\Office\Model\DepartmentFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;

class Employee extends \Magento\Framework\View\Element\Template
{
    const DEPARTMENTTABLE = "dtn_office_department";
    const EMPLOYEETABLE = "dtn_office_employee_entity";
    protected $_coreRegistry;
	protected $_employeeFactory;
    protected $_departmentFactory;

    public function __construct(
        \Magento\Framework\Registry $coreRegistry,
    	\Magento\Framework\View\Element\Template\Context $context,
    	\DTN\Office\Model\EmployeeFactory $employeeFactory,
        \DTN\Office\Model\DepartmentFactory $departmentFactory
    )
    {
        $this->_departmentFactory = $departmentFactory;
    	$this->_employeeFactory = $employeeFactory;
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context);

    }

    public function getDepartment()
    {
        return $this->_departmentFactory->create()->getCollection();
    }

    // public function getEmployee()
    // {
    // 	return $this->_employeeFactory->create()->getCollection();
    // }

    public function join()
    {  
        $collection = $this->_employeeFactory->create()->getCollection();
         
        $collection->getSelect()->joinLeft(
            array('department' => self::DEPARTMENTTABLE),
            'main_table.department_id = department.entity_id');

        return $collection->getData();
    }

    public function addEmployee()
    {   
        return '/office/employee/insert';
    }

    public function delete()
    {   
        return '/office/employee/delete';
    }

    public function editRecord()
    {
        $id = $this->_coreRegistry->registry('editRecordId');      
        $employee = $this->_employeeFactory->create();
        return $employee->load($id)->getData();
        // return $id;
    }

    public function edit()
    {   
        return '/office/employee/edit';
    }

    public function update()
    {   
        return '/office/employee/update';
    }

}

